package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.BoundingBoxEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.StrafeEvent;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.movement.longs.LongJumpMode;
import dev.tenacity.module.settings.impl.ModeSetting;

public final class LongJump extends Module {

    public static final ModeSetting mode = new ModeSetting("Mode", "Latest NCP", "Latest NCP");
    public static final ModeSetting latestNCPMode = new ModeSetting("Latest NCP Mode", "Normal", "Normal", "Clip");

    private LongJumpMode jump;

    public LongJump() {
        super("LongJump", Category.MOVEMENT, "Allows you to jump further.");

        this.latestNCPMode.addParent(mode, visible -> mode.is("Latest NCP"));

        this.addSettings(mode, latestNCPMode);

        LongJumpMode.init();
    }

    @Override
    public void onEnable() {
        this.jump = LongJumpMode.get(mode.getMode());
        this.jump.onEnable();
        Tenacity.INSTANCE.getEventProtocol().register(this.jump);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.jump = LongJumpMode.get(mode.getMode());
        this.jump.onDisable();
        Tenacity.INSTANCE.getEventProtocol().unregister(this.jump);
        super.onDisable();
    }
}
